var timer1,timer2,timer3,timer4,timer5,timer6;
var counter1=5,counter2,counter3,counter4,counter5,counter6;
var url1,url2,url3,url4,url5,url6;
var timerlimit=20000;
url1="http://ava.ua/category/10/34/"; counter1=17;
url2="http://ava.ua/category/10/182/"; counter2=5;
url3="http://ava.ua/category/10/43/"; counter3=7;
url4="http://ava.ua/category/10/36/"; counter4=18;
url5="http://ava.ua/category/10/183/"; counter5=23;

$( "#but" ).click(function() {

console.log('click');
 timer1= setInterval(function() {
            var urltemp='';                   
    if(counter1>1){urltemp=url1+'p'+counter1+'/'; }
    else{urltemp=url1; }

send_post(urltemp);
   //console.log(urltemp);

  if(--counter1<1){  clearInterval(timer1);}
}, timerlimit);

 //-------------2      UNCOMENT 
                 

/* timer2= setInterval(function() {
            var urltemp='';                   
    if(counter2>1){urltemp=url2+'p'+counter2+'/'; }
    else{urltemp=url2; }

send_post(urltemp);
   //console.log(urltemp);

  if(--counter2<1){  clearInterval(timer2);}
}, timerlimit);

 //-------------3


 timer3= setInterval(function() {
            var urltemp='';                   
    if(counter3>1){urltemp=url3+'p'+counter3+'/'; }
    else{urltemp=url3; }

send_post(urltemp);
   //console.log(urltemp);

  if(--counter3<1){  clearInterval(timer3);}
}, timerlimit);


 //-------------4


 timer4= setInterval(function() {
            var urltemp='';                   
    if(counter4>1){urltemp=url4+'p'+counter4+'/'; }
    else{urltemp=url4; }

send_post(urltemp);
   //console.log(urltemp);

  if(--counter4<1){  clearInterval(timer4);}
}, timerlimit);


 //-------------5


 timer5= setInterval(function() {
            var urltemp='';                   
    if(counter5>1){urltemp=url5+'p'+counter5+'/'; }
    else{urltemp=url5; }

send_post(urltemp);
   //console.log(urltemp);

  if(--counter5<1){  clearInterval(timer5);}
}, timerlimit);



*/




});




//     send post
function send_post(url) {
	// body...
$.post(
  "../gotopage.php",
  {
    parmurl: url,
  },
  onAjaxSuccess
);


}

//     ok 
function onAjaxSuccess(data)
{
  // Здесь мы получаем данные, отправленные сервером и выводим их на экран.
  console.log(data);
}