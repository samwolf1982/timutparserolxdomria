<?php


/*define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'opencarta1');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
*/
if (is_file('config.php')) {
	require_once('config.php');
}






//**********************
//echo "string ";


function create_insert($value='')
{
	# code...
}

function create_update_image($value='')
{
	# code...
}
function create_insert_descr($value='')
{
	# code...
}

function get_last_id($mysqli)
{
	# code...
if ($result = $mysqli->query("SELECT LAST_INSERT_ID() as total")) {
	$data=mysqli_fetch_assoc($result);
//echo $data['total'];
   // printf("Select вернул %d строк.\n", $result->num_rows);
 
    //$row = $result->fetch_row();
//var_dump($result);
    //printf ("Citycc: %s  \n", $result);
/*  echo mysqli_result($result,0);
    echo mysqli_result($result,1);*/
    /* очищаем результирующий набор */
    $result->close();
    return $data['total'];
}

}


// from parse



require_once ('phpQuery/phpQuery/phpQuery.php');
require_once 'php5/setings.php';

require_once 'php5/PhpDebuger/debug.php';




scanx('http://ava.ua/category/18/59/');


 function scanx($path_site)
{
 
  //$path_site='http://alitrust.ru/boasts/odezhda-i-obuv';
  # code...
  phpQuery::ajaxAllowHost($GLOBALS['curent_host']); 

  
 /* $file_c = file_get_contents($GLOBALS['path_hash']);
  $all_hasess = explode(",",trim($file_c));
  $GLOBALS['counter']=count($all_hasess);
*/

  phpQuery::get($path_site,function ($do) use ($path_site)
    {
      # code...
      /*   $arrayName = array('main' =>'div.b-boast-list__item:nth-child() ', 'links_add_a'=>'div.b-boast-list__item:nth-child(' ); //x
*/
         // заход на любую страницу пускай 31
         // http://anti-free.ru/forum/showthread.php?t=58815&page=31 
         // поиск а указателя на ссилку на последниюю ссілку

      $document=phpQuery::newDocument($do);
    // echo "$document";  
     // парс ст. +отправка и сверка
      parse($document,$path_site);
    
        
  
      // потом встаить в цикл + проверка

  //echo nl2br("\nok");


     //end anonim n GET
    }); 




// end fun scanx    
}


 function parse($value2,$path_site)
 {
   # code...
  $document=$value2;
                  // парс без параметров 
                        // если есть совпадения сразу брейк.
#posts > div:nth-child(4)     // количество елементов на странице
// удалить все пости спасибо  post_thanks_box_
 $s='div[class^="item"]';


$res=$document->find($s);

echo "string";
echo count($res);


$result=array();


  foreach ($res as $key => $value) {
  	# code...
  	$temp=pq($value)->text();
$res_text=$temp;
  	//echo "value TEXT: ".pq($value)->text()."<br><br>";
  // find image
            $im= pq($value)->find('img');
           // echo "<br>cddd ".count($im).'<br>';
            // take foto
            echo "IMAGE ". count($im)." IMAGE";
            $res_img='';
            foreach ($im as $key1 => $value1) {
              # code...
                   $res_img=pq($value1)->attr('src');
            }
            echo $im;
            if(count($im)>0){
            $rand=rand();
            $catalog="image/";
            $path_to_image='catalog/prs/a'.$rand.'.jpg';
            file_put_contents($catalog.$path_to_image, file_get_contents($res_img));
 chmod(DIR_IMAGE.$path_to_image,777);
$res_img=$path_to_image;

}
             $im= pq($value)->find('.price');

             foreach ($im as $key => $value) {
              	# code...
              	 printf("Price %s",pq($value)->text());

              } 
             


//************


$mysqli = new mysqli(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

/* проверка соединения */
if ($mysqli->connect_errno) {
    printf("Не удалось подключиться: %s\n", $mysqli->connect_error);
    exit();
}


//********************


$xxx="INSERT INTO oc_product SET model = 'zzzzzzzz', sku = '', upc = '', ean = '', jan = '', isbn = '', mpn = '', location = '', quantity = '1111', minimum = '1', subtract = '1', stock_status_id = '6', date_available = '2016-05-02', manufacturer_id = '0', shipping = '1', price = '0', points = '0', weight = '0', weight_class_id = '1', length = '0', width = '0', height = '0', length_class_id = '1', status = '1', tax_class_id = '0', sort_order = '1', date_added = NOW()";
// ok

if ($result = $mysqli->query($xxx)) {
   // printf("Select вернул____ %d строк.\n", $result->num_rows);
 
    //$row = $result->fetch_row();
    echo "add ok";

}
 
 $last_id=get_last_id($mysqli);
 
 //        for image test
 //$res_img='catalog/d.png';
     
$for_image="UPDATE oc_product SET image = '".$res_img."' WHERE product_id = '".$last_id."'";

echo "<br>---".$for_image."  --<br>";
if ($result = $mysqli->query($for_image)) {
   // printf("Select вернул____ %d строк.\n", $result->num_rows);
 
    //$row = $result->fetch_row();
    echo "add image";
 
}

echo "<br> Descript <br>";
$may_des=$res_text;
$des="INSERT INTO oc_product_description SET product_id = '".$last_id."', language_id = '1', name = 'with imag2', description = '".$may_des."', tag = '', meta_title = 'meta wirh image 2', meta_description = '', meta_keyword = ''";
if ($result = $mysqli->query($des)) {
   // printf("Select вернул____ %d строк.\n", $result->num_rows);
 
    //$row = $result->fetch_row();
    echo "add desc";
 
}


$mysqli->close();



 

            //*****************


  	//echo "value IMAGE ";
  }

//*********
 

 }









?>