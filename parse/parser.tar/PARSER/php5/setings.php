<?php
$GLOBALS['path_hash'] = '/var/www/html/wp-content/plugins/megaparse/php5/hasess.txt';
$GLOBALS['path_to_WP'] = 'http://testfordel.atwebpages.com/api/create_post';

$GLOBALS['path_to_WP'] = 'http://www.imageplugin.dev';


$GLOBALS['author'] = 'root';
$GLOBALS['full_update'] = false;
$GLOBALS['counter'] = 0;  // просто счетчик
$GLOBALS['forum']='http://anti-free.ru/forum';


$GLOBALS['curent_host'] = 'ava.ua';
$GLOBALS['curent_host_full'] = 'http://ava.ua/';

?>