<?php

/**
* 
*/
class Show
{
	
	function __construct(argument)
	{
		# code...
	}

 static public function echo($value='')
 {
 	# code...

 	echo "string";
 }
}


?>